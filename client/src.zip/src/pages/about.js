import React from "react";

const About = () => {
return (
	<div>
	<h1>
		About StudentHub
	</h1>
	<p>StudentHub is a project created using React + Flask(Python)</p>
	</div>
);
};

export default About;
